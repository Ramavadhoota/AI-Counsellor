'use client';

import React, { useState } from 'react';
import { AcademicForm } from './AcademicForm';
import { GoalsForm } from './GoalsForm';
import { BudgetForm } from './BudgetForm';
import { ExamsForm } from './ExamsForm';
import { Progress } from '@/components/ui/Progress';
import { Button } from '@/components/ui/Button';

const STEPS = ['Academic Background', 'Study Goals', 'Budget & Funding', 'Exam Readiness'];

interface OnboardingWizardProps {
  onComplete: (data: any) => void;
  loading: boolean;
}

export const OnboardingWizard: React.FC<OnboardingWizardProps> = ({ onComplete, loading }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({});

  const updateFormData = (stepData: any) => {
    setFormData({ ...formData, ...stepData });
  };

  const handleNext = (stepData: any) => {
    updateFormData(stepData);
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = (stepData: any) => {
    const finalData = { ...formData, ...stepData };
    onComplete(finalData);
  };

  return (
    <div>
      <div className="mb-8">
        <Progress value={(currentStep + 1) / STEPS.length * 100} showLabel />
        <div className="flex justify-between mt-2">
          {STEPS.map((step, index) => (
            <span
              key={index}
              className={`text-sm ${
                index <= currentStep ? 'text-primary' : 'text-gray-500'
              }`}
            >
              {step}
            </span>
          ))}
        </div>
      </div>

      {currentStep === 0 && <AcademicForm onNext={handleNext} initialData={formData} />}
      {currentStep === 1 && <GoalsForm onNext={handleNext} initialData={formData} />}
      {currentStep === 2 && <BudgetForm onNext={handleNext} initialData={formData} />}
      {currentStep === 3 && <ExamsForm onSubmit={handleSubmit} initialData={formData} loading={loading} />}

      {currentStep > 0 && (
        <Button variant="secondary" onClick={handlePrevious} className="mt-4">
          Previous
        </Button>
      )}
    </div>
  );
};

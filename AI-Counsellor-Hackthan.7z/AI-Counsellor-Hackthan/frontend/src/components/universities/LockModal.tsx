import React from 'react';
import { Modal } from '@/components/ui/Modal';
import { Button } from '@/components/ui/Button';
import type { University } from '@/types';

interface LockModalProps {
  isOpen: boolean;
  university: University | null;
  onClose: () => void;
  onConfirm: () => void;
}

export const LockModal: React.FC<LockModalProps> = ({
  isOpen,
  university,
  onClose,
  onConfirm,
}) => {
  if (!university) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Lock University" size="md">
      <div className="space-y-4">
        <p className="text-gray-300">
          Locking <strong className="text-white">{university.name}</strong> will:
        </p>
        <ul className="list-disc list-inside text-gray-400 space-y-2">
          <li>Focus your application strategy on this university</li>
          <li>Unlock application guidance and personalized tasks</li>
          <li>Generate a detailed to-do list for this application</li>
          <li>Update your dashboard with university-specific milestones</li>
        </ul>
        <div className="bg-warning/10 border border-warning/30 rounded-lg p-3">
          <p className="text-sm text-gray-300">
            ⚠️ You can unlock later if needed, but it's recommended to commit once you're ready.
          </p>
        </div>
        <div className="flex gap-3 mt-6">
          <Button variant="secondary" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button onClick={onConfirm} className="flex-1">
            Confirm Lock
          </Button>
        </div>
      </div>
    </Modal>
  );
};

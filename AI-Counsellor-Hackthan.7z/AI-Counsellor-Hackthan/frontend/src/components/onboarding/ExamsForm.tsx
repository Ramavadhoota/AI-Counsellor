'use client';

import React, { useState } from 'react';
import { Select } from '@/components/ui/Select';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

interface ExamsFormProps {
  onSubmit: (data: any) => void;
  initialData: any;
  loading: boolean;
}

export const ExamsForm: React.FC<ExamsFormProps> = ({ onSubmit, initialData, loading }) => {
  const [formData, setFormData] = useState({
    ielts_status: initialData.ielts_status || '',
    gre_status: initialData.gre_status || '',
    sop_status: initialData.sop_status || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Card>
      <form onSubmit={handleSubmit} className="space-y-4">
        <h2 className="text-xl font-semibold text-white mb-4">Exam Readiness</h2>
        
        <Select
          label="IELTS/TOEFL Status"
          options={[
            { value: '', label: 'Select...' },
            { value: 'not_started', label: 'Not Started' },
            { value: 'preparing', label: 'Preparing' },
            { value: 'completed', label: 'Completed' },
          ]}
          value={formData.ielts_status}
          onChange={(e) => setFormData({ ...formData, ielts_status: e.target.value })}
          required
        />
        
        <Select
          label="GRE/GMAT Status"
          options={[
            { value: '', label: 'Select...' },
            { value: 'not_started', label: 'Not Started' },
            { value: 'preparing', label: 'Preparing' },
            { value: 'completed', label: 'Completed' },
            { value: 'not_required', label: 'Not Required' },
          ]}
          value={formData.gre_status}
          onChange={(e) => setFormData({ ...formData, gre_status: e.target.value })}
          required
        />
        
        <Select
          label="SOP (Statement of Purpose) Status"
          options={[
            { value: '', label: 'Select...' },
            { value: 'not_started', label: 'Not Started' },
            { value: 'draft', label: 'Draft Ready' },
            { value: 'ready', label: 'Finalized' },
          ]}
          value={formData.sop_status}
          onChange={(e) => setFormData({ ...formData, sop_status: e.target.value })}
          required
        />

        <div className="bg-success/10 border border-success/30 rounded-lg p-4 mt-4">
          <p className="text-sm text-gray-300">
            ✅ <strong>Almost Done!</strong> Click Complete Profile to unlock your AI Counsellor 
            and personalized university recommendations.
          </p>
        </div>

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? 'Completing...' : 'Complete Profile'}
        </Button>
      </form>
    </Card>
  );
};

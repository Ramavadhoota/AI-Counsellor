import React from 'react';
import { Card } from '@/components/ui/Card';
import { Select } from '@/components/ui/Select';
import { Input } from '@/components/ui/Input';

interface FilterSidebarProps {
  filters: {
    country?: string;
    category?: string;
    budgetMax?: number;
  };
  onFilterChange: (filters: any) => void;
}

export const FilterSidebar: React.FC<FilterSidebarProps> = ({ filters, onFilterChange }) => {
  return (
    <Card>
      <h3 className="text-lg font-semibold text-white mb-4">Filters</h3>
      
      <div className="space-y-4">
        <Select
          label="Country"
          options={[
            { value: '', label: 'All Countries' },
            { value: 'USA', label: 'USA' },
            { value: 'UK', label: 'UK' },
            { value: 'Canada', label: 'Canada' },
            { value: 'Australia', label: 'Australia' },
            { value: 'Germany', label: 'Germany' },
          ]}
          value={filters.country || ''}
          onChange={(e) => onFilterChange({ ...filters, country: e.target.value })}
        />
        
        <Select
          label="Category"
          options={[
            { value: '', label: 'All Categories' },
            { value: 'dream', label: 'Dream' },
            { value: 'target', label: 'Target' },
            { value: 'safe', label: 'Safe' },
          ]}
          value={filters.category || ''}
          onChange={(e) => onFilterChange({ ...filters, category: e.target.value })}
        />
        
        <Input
          type="number"
          label="Max Budget (USD/year)"
          placeholder="50000"
          value={filters.budgetMax || ''}
          onChange={(e) => onFilterChange({ ...filters, budgetMax: parseInt(e.target.value) })}
        />
      </div>
    </Card>
  );
};

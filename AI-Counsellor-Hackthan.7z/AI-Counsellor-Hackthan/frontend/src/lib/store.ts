import { create } from 'zustand';
import { User, OnboardingData, University, TodoItem, Stage } from '@/types';

interface AppState {
  user: User | null;
  onboardingData: OnboardingData | null;
  universities: University[];
  todos: TodoItem[];
  currentStage: Stage;
  loading: boolean;
  
  setUser: (user: User | null) => void;
  setOnboardingData: (data: OnboardingData | null) => void;
  setUniversities: (universities: University[]) => void;
  setTodos: (todos: TodoItem[]) => void;
  setCurrentStage: (stage: Stage) => void;
  setLoading: (loading: boolean) => void;
  
  addTodo: (todo: TodoItem) => void;
  updateTodo: (id: string, updates: Partial<TodoItem>) => void;
  deleteTodo: (id: string) => void;
  
  shortlistUniversity: (id: string) => void;
  lockUniversity: (id: string) => void;
  unlockUniversity: (id: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  user: null,
  onboardingData: null,
  universities: [],
  todos: [],
  currentStage: 'building_profile',
  loading: false,
  
  setUser: (user) => set({ user }),
  setOnboardingData: (data) => set({ onboardingData: data }),
  setUniversities: (universities) => set({ universities }),
  setTodos: (todos) => set({ todos }),
  setCurrentStage: (stage) => set({ currentStage: stage }),
  setLoading: (loading) => set({ loading }),
  
  addTodo: (todo) => set((state) => ({ todos: [...state.todos, todo] })),
  
  updateTodo: (id, updates) =>
    set((state) => ({
      todos: state.todos.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    })),
  
  deleteTodo: (id) =>
    set((state) => ({
      todos: state.todos.filter((t) => t.id !== id),
    })),
  
  shortlistUniversity: (id) =>
    set((state) => ({
      universities: state.universities.map((u) =>
        u.id === id ? { ...u, shortlisted: true } : u
      ),
    })),
  
  lockUniversity: (id) =>
    set((state) => ({
      universities: state.universities.map((u) =>
        u.id === id ? { ...u, locked: true } : u
      ),
    })),
  
  unlockUniversity: (id) =>
    set((state) => ({
      universities: state.universities.map((u) =>
        u.id === id ? { ...u, locked: false } : u
      ),
    })),
}));

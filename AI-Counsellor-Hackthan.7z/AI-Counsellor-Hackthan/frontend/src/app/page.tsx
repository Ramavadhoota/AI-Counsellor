'use client';

import React from 'react';
import Link from 'next/link';
import { ArrowRight, Target, Brain, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

export default function LandingPage() {
  const features = [
    {
      icon: <Brain className="w-8 h-8 text-primary" />,
      title: 'AI-Powered Guidance',
      description: 'Get personalized recommendations based on your academic profile and goals',
    },
    {
      icon: <Target className="w-8 h-8 text-primary" />,
      title: 'Stage-Based Flow',
      description: 'Clear, structured journey from profile building to application submission',
    },
    {
      icon: <CheckCircle className="w-8 h-8 text-primary" />,
      title: 'Action-Oriented',
      description: 'AI takes actions - shortlists universities, creates tasks, locks decisions',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-primary-dark rounded-lg" />
              <span className="text-xl font-bold text-white">AI Counsellor</span>
            </div>
            <Link href="/login">
              <Button variant="ghost">Login</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Plan Your Study-Abroad Journey with{' '}
            <span className="gradient-text">AI Guidance</span>
          </h1>
          <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
            Stop feeling overwhelmed. Get a clear, step-by-step path from confusion to
            acceptance with personalized AI counseling.
          </p>
          <div className="flex gap-4 justify-center">
            <Link href="/signup">
              <Button size="lg" className="group">
                Get Started
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="/login">
              <Button size="lg" variant="outline">
                Login
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4 bg-surface/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-white mb-12">
            How It Works
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} hover>
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-400">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="bg-gradient-to-br from-primary/10 to-primary-dark/10 border-primary/20">
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Start Your Journey?
            </h2>
            <p className="text-gray-300 mb-6">
              Join thousands of students getting clarity on their study abroad plans
            </p>
            <Link href="/signup">
              <Button size="lg">Create Free Account</Button>
            </Link>
          </Card>
        </div>
      </section>
    </div>
  );
}

'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Search, MapPin, DollarSign, TrendingUp, Lock, Star } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { universitiesAPI } from '@/lib/api';
import { useAppStore } from '@/lib/store';
import toast from 'react-hot-toast';

export default function UniversitiesPage() {
  const { universities, setUniversities } = useAppStore();
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'dream' | 'target' | 'safe'>('all');
  const [lockModalOpen, setLockModalOpen] = useState(false);
  const [selectedUni, setSelectedUni] = useState<any>(null);

  useEffect(() => {
    loadUniversities();
  }, []);

  const loadUniversities = async () => {
    try {
      const response = await universitiesAPI.search();
      setUniversities(response.data);
    } catch (error) {
      toast.error('Failed to load universities');
    } finally {
      setLoading(false);
    }
  };

  const handleShortlist = async (uniId: string) => {
    try {
      await universitiesAPI.shortlist(uniId);
      setUniversities(
        universities.map(u => u.id === uniId ? { ...u, shortlisted: true } : u)
      );
      toast.success('University shortlisted!');
    } catch (error) {
      toast.error('Failed to shortlist');
    }
  };

  const handleLock = async (notes?: string) => {
    if (!selectedUni) return;
    
    try {
      await universitiesAPI.lock(selectedUni.id, notes);
      setUniversities(
        universities.map(u => u.id === selectedUni.id ? { ...u, locked: true } : u)
      );
      toast.success('University locked! Application guidance unlocked.');
      setLockModalOpen(false);
    } catch (error) {
      toast.error('Failed to lock university');
    }
  };

  const filteredUniversities = universities.filter(uni => {
    const matchesSearch = uni.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          uni.country.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || uni.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryColor = (category: string) => {
    const colors = {
      dream: 'bg-warning/20 text-warning border-warning/30',
      target: 'bg-primary/20 text-primary border-primary/30',
      safe: 'bg-success/20 text-success border-success/30',
    };
    return colors[category as keyof typeof colors] || '';
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-white">Discover Universities</h1>
              <p className="text-gray-400">AI-recommended based on your profile</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Search & Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 w-5 h-5" />
              <Input
                placeholder="Search universities..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex gap-2">
            {['all', 'dream', 'target', 'safe'].map((cat) => (
              <Button
                key={cat}
                variant={selectedCategory === cat ? 'primary' : 'secondary'}
                onClick={() => setSelectedCategory(cat as any)}
                className="capitalize"
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>

        {/* Universities Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="text-white text-xl">Loading universities...</div>
          </div>
        ) : filteredUniversities.length === 0 ? (
          <Card className="text-center py-12">
            <p className="text-gray-400">No universities found matching your criteria</p>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredUniversities.map((uni) => (
              <Card key={uni.id} hover className="flex flex-col">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-lg font-semibold text-white flex-1">{uni.name}</h3>
                  <Badge className={getCategoryColor(uni.category)}>
                    {uni.category}
                  </Badge>
                </div>

                <div className="space-y-2 mb-4 flex-1">
                  <div className="flex items-center text-gray-400 text-sm">
                    <MapPin className="w-4 h-4 mr-2" />
                    {uni.city}, {uni.country}
                  </div>
                  
                  <div className="flex items-center text-gray-400 text-sm">
                    <DollarSign className="w-4 h-4 mr-2" />
                    ${uni.tuition_min.toLocaleString()} - ${uni.tuition_max.toLocaleString()}/year
                  </div>
                  
                  <div className="flex items-center text-gray-400 text-sm">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    {(uni.acceptance_rate * 100).toFixed(0)}% acceptance rate
                  </div>
                </div>

                {/* Fit Score */}
                <div className="mb-4 p-3 bg-elevated rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-400">Profile Fit</span>
                    <span className="text-sm font-semibold text-primary">{uni.fit_score}%</span>
                  </div>
                  <div className="w-full h-2 bg-surface rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-primary to-primary-dark"
                      style={{ width: `${uni.fit_score}%` }}
                    />
                  </div>
                </div>

                {/* Why Fits */}
                {uni.why_fits && uni.why_fits.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-400 mb-2">Why it fits:</p>
                    <ul className="text-sm text-gray-300 space-y-1">
                      {uni.why_fits.slice(0, 2).map((reason, idx) => (
                        <li key={idx} className="flex items-start">
                          <span className="text-success mr-2">✓</span>
                          {reason}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 mt-auto">
                  {uni.locked ? (
                    <Badge variant="success" className="flex-1 justify-center py-2">
                      <Lock className="w-4 h-4 mr-1" />
                      Locked
                    </Badge>
                  ) : uni.shortlisted ? (
                    <>
                      <Badge variant="info" className="flex-1 justify-center py-2">
                        <Star className="w-4 h-4 mr-1" />
                        Shortlisted
                      </Badge>
                      <Button
                        size="sm"
                        onClick={() => {
                          setSelectedUni(uni);
                          setLockModalOpen(true);
                        }}
                      >
                        <Lock className="w-4 h-4 mr-1" />
                        Lock
                      </Button>
                    </>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => handleShortlist(uni.id)}
                    >
                      Shortlist
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Lock Modal */}
      <Modal
        isOpen={lockModalOpen}
        onClose={() => setLockModalOpen(false)}
        title="Lock University"
        size="md"
      >
        <div className="space-y-4">
          <p className="text-gray-300">
            Locking <strong>{selectedUni?.name}</strong> will:
          </p>
          <ul className="list-disc list-inside text-gray-400 space-y-2">
            <li>Focus your application strategy on this university</li>
            <li>Unlock application guidance and tasks</li>
            <li>Generate personalized to-do items</li>
          </ul>
          <p className="text-sm text-gray-500">
            You can unlock later if needed, but it's recommended to commit once ready.
          </p>
          <div className="flex gap-3">
            <Button variant="secondary" onClick={() => setLockModalOpen(false)} className="flex-1">
              Cancel
            </Button>
            <Button onClick={() => handleLock()} className="flex-1">
              Confirm Lock
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

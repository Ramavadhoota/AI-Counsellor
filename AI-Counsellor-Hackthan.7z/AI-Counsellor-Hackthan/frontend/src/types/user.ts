export interface User {
  id: string;
  email: string;
  full_name: string;
  onboarding_completed: boolean;
  created_at: string;
}

export interface UserProfile extends User {
  education_level?: string;
  degree?: string;
  major?: string;
  graduation_year?: number;
  gpa?: number;
  intended_degree?: string;
  field_of_study?: string;
  target_intake?: string;
  preferred_countries?: string[];
  budget_min?: number;
  budget_max?: number;
  funding_plan?: string;
  ielts_status?: string;
  gre_status?: string;
  sop_status?: string;
}

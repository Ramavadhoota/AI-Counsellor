'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Progress } from '@/components/ui/Progress';
import { onboardingAPI } from '@/lib/api';
import { useAppStore } from '@/lib/store';

const STEPS = ['Academic Background', 'Study Goals', 'Budget & Funding', 'Exam Readiness'];

export default function OnboardingPage() {
  const router = useRouter();
  const setUser = useAppStore((state) => state.setUser);
  const setOnboardingData = useAppStore((state) => state.setOnboardingData);
  
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    // Step 1
    education_level: '',
    degree: '',
    major: '',
    graduation_year: new Date().getFullYear(),
    gpa: '',
    
    // Step 2
    intended_degree: '',
    field_of_study: '',
    target_intake: '',
    preferred_countries: [] as string[],
    
    // Step 3
    budget_min: '',
    budget_max: '',
    funding_plan: '',
    
    // Step 4
    ielts_status: '',
    gre_status: '',
    sop_status: '',
  });

  const updateField = (field: string, value: any) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleNext = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const response = await onboardingAPI.complete({
        ...formData,
        budget_min: parseInt(formData.budget_min),
        budget_max: parseInt(formData.budget_max),
      });
      
      setOnboardingData(response.data);
      setUser((prev) => prev ? { ...prev, onboarding_completed: true } : null);
      
      toast.success('Profile completed! Welcome to AI Counsellor');
      router.push('/dashboard');
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to complete onboarding');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Complete Your Profile</h1>
          <p className="text-gray-400">Help us understand your background and goals</p>
        </div>

        <div className="mb-8">
          <Progress value={(currentStep + 1) / STEPS.length * 100} showLabel />
          <div className="flex justify-between mt-2">
            {STEPS.map((step, index) => (
              <span
                key={index}
                className={`text-sm ${
                  index <= currentStep ? 'text-primary' : 'text-gray-500'
                }`}
              >
                {step}
              </span>
            ))}
          </div>
        </div>

        <Card>
          {/* Step 1: Academic Background */}
          {currentStep === 0 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-white mb-4">Academic Background</h2>
              
              <Select
                label="Current Education Level"
                options={[
                  { value: '', label: 'Select...' },
                  { value: 'high_school', label: 'High School' },
                  { value: 'bachelors', label: "Bachelor's Degree" },
                  { value: 'masters', label: "Master's Degree" },
                ]}
                value={formData.education_level}
                onChange={(e) => updateField('education_level', e.target.value)}
              />
              
              <Input
                label="Current Degree/Diploma"
                placeholder="e.g., B.Tech, BSc, 12th Grade"
                value={formData.degree}
                onChange={(e) => updateField('degree', e.target.value)}
              />
              
              <Input
                label="Major/Stream"
                placeholder="e.g., Computer Science, Commerce"
                value={formData.major}
                onChange={(e) => updateField('major', e.target.value)}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <Input
                  type="number"
                  label="Graduation Year"
                  value={formData.graduation_year}
                  onChange={(e) => updateField('graduation_year', parseInt(e.target.value))}
                />
                
                <Input
                  type="number"
                  step="0.01"
                  label="GPA/Percentage (Optional)"
                  placeholder="e.g., 3.5 or 85"
                  value={formData.gpa}
                  onChange={(e) => updateField('gpa', e.target.value)}
                />
              </div>
            </div>
          )}

          {/* Step 2: Study Goals */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-white mb-4">Study Goals</h2>
              
              <Select
                label="Intended Degree"
                options={[
                  { value: '', label: 'Select...' },
                  { value: 'bachelors', label: "Bachelor's" },
                  { value: 'masters', label: "Master's" },
                  { value: 'mba', label: 'MBA' },
                  { value: 'phd', label: 'PhD' },
                ]}
                value={formData.intended_degree}
                onChange={(e) => updateField('intended_degree', e.target.value)}
              />
              
              <Input
                label="Field of Study"
                placeholder="e.g., Computer Science, Business, Medicine"
                value={formData.field_of_study}
                onChange={(e) => updateField('field_of_study', e.target.value)}
              />
              
              <Input
                label="Target Intake"
                placeholder="e.g., Fall 2024, Spring 2025"
                value={formData.target_intake}
                onChange={(e) => updateField('target_intake', e.target.value)}
              />
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Preferred Countries
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['USA', 'UK', 'Canada', 'Australia', 'Germany', 'Ireland'].map((country) => (
                    <label key={country} className="flex items-center space-x-2 text-gray-300">
                      <input
                        type="checkbox"
                        checked={formData.preferred_countries.includes(country)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            updateField('preferred_countries', [...formData.preferred_countries, country]);
                          } else {
                            updateField('preferred_countries', formData.preferred_countries.filter(c => c !== country));
                          }
                        }}
                        className="rounded border-border text-primary focus:ring-primary"
                      />
                      <span>{country}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Budget */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-white mb-4">Budget & Funding</h2>
              
              <div className="grid grid-cols-2 gap-4">
                <Input
                  type="number"
                  label="Minimum Budget (USD/year)"
                  placeholder="15000"
                  value={formData.budget_min}
                  onChange={(e) => updateField('budget_min', e.target.value)}
                />
                
                <Input
                  type="number"
                  label="Maximum Budget (USD/year)"
                  placeholder="30000"
                  value={formData.budget_max}
                  onChange={(e) => updateField('budget_max', e.target.value)}
                />
              </div>
              
              <Select
                label="Funding Plan"
                options={[
                  { value: '', label: 'Select...' },
                  { value: 'self_funded', label: 'Self-Funded' },
                  { value: 'scholarship', label: 'Scholarship-Dependent' },
                  { value: 'loan', label: 'Education Loan' },
                  { value: 'mixed', label: 'Mixed (Self + Loan/Scholarship)' },
                ]}
                value={formData.funding_plan}
                onChange={(e) => updateField('funding_plan', e.target.value)}
              />
            </div>
          )}

          {/* Step 4: Exam Readiness */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <h2 className="text-xl font-semibold text-white mb-4">Exam Readiness</h2>
              
              <Select
                label="IELTS/TOEFL Status"
                options={[
                  { value: '', label: 'Select...' },
                  { value: 'not_started', label: 'Not Started' },
                  { value: 'preparing', label: 'Preparing' },
                  { value: 'completed', label: 'Completed' },
                ]}
                value={formData.ielts_status}
                onChange={(e) => updateField('ielts_status', e.target.value)}
              />
              
              <Select
                label="GRE/GMAT Status"
                options={[
                  { value: '', label: 'Select...' },
                  { value: 'not_started', label: 'Not Started' },
                  { value: 'preparing', label: 'Preparing' },
                  { value: 'completed', label: 'Completed' },
                  { value: 'not_required', label: 'Not Required' },
                ]}
                value={formData.gre_status}
                onChange={(e) => updateField('gre_status', e.target.value)}
              />
              
              <Select
                label="SOP (Statement of Purpose) Status"
                options={[
                  { value: '', label: 'Select...' },
                  { value: 'not_started', label: 'Not Started' },
                  { value: 'draft', label: 'Draft Ready' },
                  { value: 'ready', label: 'Finalized' },
                ]}
                value={formData.sop_status}
                onChange={(e) => updateField('sop_status', e.target.value)}
              />
            </div>
          )}

          {/* Navigation */}
          <div className="flex justify-between mt-8">
            <Button
              variant="secondary"
              onClick={handlePrevious}
              disabled={currentStep === 0}
            >
              Previous
            </Button>
            
            {currentStep < STEPS.length - 1 ? (
              <Button onClick={handleNext}>Next</Button>
            ) : (
              <Button onClick={handleSubmit} disabled={loading}>
                {loading ? 'Completing...' : 'Complete Profile'}
              </Button>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

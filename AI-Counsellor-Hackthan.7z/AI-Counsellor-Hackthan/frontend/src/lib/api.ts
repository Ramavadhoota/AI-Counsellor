import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;

// Auth API
export const authAPI = {
  signup: (data: { email: string; password: string; full_name: string }) =>
    api.post('/auth/signup', data),
  
  login: (data: { email: string; password: string }) =>
    api.post('/auth/login', data),
  
  logout: () => api.post('/auth/logout'),
};

// Onboarding API
export const onboardingAPI = {
  complete: (data: any) => api.post('/onboarding/complete', data),
  
  getStatus: () => api.get('/onboarding/status'),
  
  update: (data: any) => api.patch('/onboarding/update', data),
};

// Profile API
export const profileAPI = {
  getMe: () => api.get('/profile/me'),
  
  updateMe: (data: any) => api.patch('/profile/me', data),
  
  getStrength: () => api.get('/profile/strength'),
};

// Counsellor API
export const counsellorAPI = {
  chat: (message: string) => api.post('/counsellor/chat', { message }),
  
  getHistory: () => api.get('/counsellor/history'),
};

// Universities API
export const universitiesAPI = {
  search: (params?: any) => api.get('/universities/search', { params }),
  
  shortlist: (universityId: string) => api.post('/universities/shortlist', { university_id: universityId }),
  
  lock: (universityId: string, notes?: string) => 
    api.post('/universities/lock', { university_id: universityId, notes }),
  
  unlock: (universityId: string) => api.post('/universities/unlock', { university_id: universityId }),
  
  getShortlisted: () => api.get('/universities/shortlisted'),
  
  getLocked: () => api.get('/universities/locked'),
};

// Todos API
export const todosAPI = {
  getAll: () => api.get('/todos'),
  
  create: (data: { title: string; description: string; category: string; deadline?: string }) =>
    api.post('/todos', data),
  
  update: (id: string, data: any) => api.patch(`/todos/${id}`, data),
  
  delete: (id: string) => api.delete(`/todos/${id}`),
  
  toggleComplete: (id: string) => api.patch(`/todos/${id}/toggle`),
};

import React from 'react';
import { UniversityCard } from './UniversityCard';
import type { University } from '@/types';

interface UniversityGridProps {
  universities: University[];
  onShortlist: (id: string) => void;
  onLock: (university: University) => void;
}

export const UniversityGrid: React.FC<UniversityGridProps> = ({
  universities,
  onShortlist,
  onLock,
}) => {
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {universities.map((university) => (
        <UniversityCard
          key={university.id}
          university={university}
          onShortlist={onShortlist}
          onLock={onLock}
        />
      ))}
    </div>
  );
};

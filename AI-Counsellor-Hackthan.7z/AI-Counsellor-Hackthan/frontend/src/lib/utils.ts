import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(date: string | Date): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(date));
}

export function calculateProfileCompletion(data: Partial<OnboardingData>): number {
  const fields = [
    'education_level', 'degree', 'major', 'graduation_year',
    'intended_degree', 'field_of_study', 'target_intake',
    'preferred_countries', 'budget_min', 'budget_max',
    'funding_plan', 'ielts_status', 'gre_status', 'sop_status'
  ];
  
  const completed = fields.filter(field => {
    const value = data[field as keyof OnboardingData];
    return value !== undefined && value !== null && value !== '';
  }).length;
  
  return Math.round((completed / fields.length) * 100);
}

export function getStageInfo(stage: Stage): { title: string; description: string } {
  const stages = {
    building_profile: {
      title: 'Building Profile',
      description: 'Complete your academic background and goals'
    },
    discovering_universities: {
      title: 'Discovering Universities',
      description: 'Explore and shortlist universities that fit your profile'
    },
    finalizing_universities: {
      title: 'Finalizing Universities',
      description: 'Lock your final university choices'
    },
    preparing_applications: {
      title: 'Preparing Applications',
      description: 'Complete tasks and prepare your applications'
    }
  };
  
  return stages[stage];
}

'use client';

import React, { useState } from 'react';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

interface AcademicFormProps {
  onNext: (data: any) => void;
  initialData: any;
}

export const AcademicForm: React.FC<AcademicFormProps> = ({ onNext, initialData }) => {
  const [formData, setFormData] = useState({
    education_level: initialData.education_level || '',
    degree: initialData.degree || '',
    major: initialData.major || '',
    graduation_year: initialData.graduation_year || new Date().getFullYear(),
    gpa: initialData.gpa || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext(formData);
  };

  return (
    <Card>
      <form onSubmit={handleSubmit} className="space-y-4">
        <h2 className="text-xl font-semibold text-white mb-4">Academic Background</h2>
        
        <Select
          label="Current Education Level"
          options={[
            { value: '', label: 'Select...' },
            { value: 'high_school', label: 'High School' },
            { value: 'bachelors', label: "Bachelor's Degree" },
            { value: 'masters', label: "Master's Degree" },
          ]}
          value={formData.education_level}
          onChange={(e) => setFormData({ ...formData, education_level: e.target.value })}
          required
        />
        
        <Input
          label="Current Degree/Diploma"
          placeholder="e.g., B.Tech, BSc, 12th Grade"
          value={formData.degree}
          onChange={(e) => setFormData({ ...formData, degree: e.target.value })}
          required
        />
        
        <Input
          label="Major/Stream"
          placeholder="e.g., Computer Science, Commerce"
          value={formData.major}
          onChange={(e) => setFormData({ ...formData, major: e.target.value })}
          required
        />
        
        <div className="grid grid-cols-2 gap-4">
          <Input
            type="number"
            label="Graduation Year"
            value={formData.graduation_year}
            onChange={(e) => setFormData({ ...formData, graduation_year: parseInt(e.target.value) })}
            required
          />
          
          <Input
            type="number"
            step="0.01"
            label="GPA/Percentage (Optional)"
            placeholder="e.g., 3.5 or 85"
            value={formData.gpa}
            onChange={(e) => setFormData({ ...formData, gpa: e.target.value })}
          />
        </div>

        <Button type="submit" className="w-full">Next</Button>
      </form>
    </Card>
  );
};

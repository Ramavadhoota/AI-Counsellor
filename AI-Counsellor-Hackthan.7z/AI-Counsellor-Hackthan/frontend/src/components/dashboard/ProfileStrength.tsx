import React from 'react';
import { Progress } from '../ui/Progress';
import { CheckCircle, Circle } from 'lucide-react';

interface ProfileItem {
  label: string;
  completed: boolean;
}

interface ProfileStrengthProps {
  items: ProfileItem[];
}

export const ProfileStrength: React.FC<ProfileStrengthProps> = ({ items }) => {
  const completedCount = items.filter((item) => item.completed).length;
  const percentage = Math.round((completedCount / items.length) * 100);

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Profile Strength</h3>
      
      <Progress
        value={percentage}
        variant={percentage < 50 ? 'danger' : percentage < 80 ? 'warning' : 'success'}
        size="lg"
        showPercentage
      />

      <div className="mt-6 space-y-3">
        {items.map((item, index) => (
          <div key={index} className="flex items-center gap-3">
            {item.completed ? (
              <CheckCircle className="w-5 h-5 text-green-600" />
            ) : (
              <Circle className="w-5 h-5 text-gray-300" />
            )}
            <span
              className={`text-sm ${
                item.completed ? 'text-gray-900 font-medium' : 'text-gray-500'
              }`}
            >
              {item.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

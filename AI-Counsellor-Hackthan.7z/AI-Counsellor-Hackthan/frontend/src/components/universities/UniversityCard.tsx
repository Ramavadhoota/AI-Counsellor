import React from 'react';
import { MapPin, DollarSign, TrendingUp, Lock, Star } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import type { University } from '@/types';

interface UniversityCardProps {
  university: University;
  onShortlist: (id: string) => void;
  onLock: (university: University) => void;
}

export const UniversityCard: React.FC<UniversityCardProps> = ({
  university,
  onShortlist,
  onLock,
}) => {
  const getCategoryColor = (category: string) => {
    const colors = {
      dream: 'bg-warning/20 text-warning border-warning/30',
      target: 'bg-primary/20 text-primary border-primary/30',
      safe: 'bg-success/20 text-success border-success/30',
    };
    return colors[category as keyof typeof colors] || '';
  };

  return (
    <Card hover className="flex flex-col h-full">
      <div className="flex items-start justify-between mb-3">
        <h3 className="text-lg font-semibold text-white flex-1">{university.name}</h3>
        <Badge className={getCategoryColor(university.category)}>
          {university.category}
        </Badge>
      </div>

      <div className="space-y-2 mb-4 flex-1">
        <div className="flex items-center text-gray-400 text-sm">
          <MapPin className="w-4 h-4 mr-2" />
          {university.city}, {university.country}
        </div>
        
        <div className="flex items-center text-gray-400 text-sm">
          <DollarSign className="w-4 h-4 mr-2" />
          ${university.tuition_min.toLocaleString()} - ${university.tuition_max.toLocaleString()}/year
        </div>
        
        <div className="flex items-center text-gray-400 text-sm">
          <TrendingUp className="w-4 h-4 mr-2" />
          {(university.acceptance_rate * 100).toFixed(0)}% acceptance rate
        </div>
      </div>

      {/* Fit Score */}
      <div className="mb-4 p-3 bg-elevated rounded-lg">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-gray-400">Profile Fit</span>
          <span className="text-sm font-semibold text-primary">{university.fit_score}%</span>
        </div>
        <div className="w-full h-2 bg-surface rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-primary-dark"
            style={{ width: `${university.fit_score}%` }}
          />
        </div>
      </div>

      {/* Why Fits */}
      {university.why_fits && university.why_fits.length > 0 && (
        <div className="mb-4">
          <p className="text-sm font-medium text-gray-400 mb-2">Why it fits:</p>
          <ul className="text-sm text-gray-300 space-y-1">
            {university.why_fits.slice(0, 2).map((reason, idx) => (
              <li key={idx} className="flex items-start">
                <span className="text-success mr-2">✓</span>
                {reason}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-2 mt-auto">
        {university.locked ? (
          <Badge variant="success" className="flex-1 justify-center py-2">
            <Lock className="w-4 h-4 mr-1" />
            Locked
          </Badge>
        ) : university.shortlisted ? (
          <>
            <Badge variant="info" className="flex-1 justify-center py-2">
              <Star className="w-4 h-4 mr-1" />
              Shortlisted
            </Badge>
            <Button
              size="sm"
              onClick={() => onLock(university)}
            >
              <Lock className="w-4 h-4 mr-1" />
              Lock
            </Button>
          </>
        ) : (
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => onShortlist(university.id)}
          >
            Shortlist
          </Button>
        )}
      </div>
    </Card>
  );
};

export interface TodoItem {
  id: string;
  title: string;
  description: string;
  category: string;
  deadline?: string;
  completed: boolean;
  created_at: string;
  updated_at?: string;
}

export interface CreateTodoInput {
  title: string;
  description: string;
  category: string;
  deadline?: string;
}

import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Main background colors
        background: '#0F172A',      // Slate 900 - Main background
        surface: '#1E293B',         // Slate 800 - Cards, surfaces
        elevated: '#334155',        // Slate 700 - Elevated elements
        
        // Primary brand colors
        primary: {
          DEFAULT: '#20B2AA',       // Light Sea Green (Teal)
          light: '#48D1CC',         // Medium Turquoise
          dark: '#1A9B94',          // Darker teal
          50: '#F0FDFC',
          100: '#CCFBF7',
          200: '#99F6F0',
          300: '#5EEAE3',
          400: '#2DD4CD',
          500: '#20B2AA',
          600: '#1A9B94',
          700: '#147D77',
          800: '#126360',
          900: '#0F5250',
        },
        
        // Secondary colors
        secondary: {
          DEFAULT: '#64748B',       // Slate 500
          light: '#94A3B8',         // Slate 400
          dark: '#475569',          // Slate 600
        },
        
        // Accent colors
        accent: {
          DEFAULT: '#38BDF8',       // Sky 400
          light: '#7DD3FC',         // Sky 300
          dark: '#0EA5E9',          // Sky 500
        },
        
        // Status colors
        success: '#10B981',         // Emerald 500
        warning: '#F59E0B',         // Amber 500
        danger: '#EF4444',          // Red 500
        info: '#3B82F6',            // Blue 500
        
        // Text colors
        text: {
          primary: '#F8FAFC',       // Slate 50
          secondary: '#CBD5E1',     // Slate 300
          muted: '#64748B',         // Slate 500
          disabled: '#475569',      // Slate 600
        },
        
        // Border colors
        border: {
          DEFAULT: '#334155',       // Slate 700
          light: '#475569',         // Slate 600
          dark: '#1E293B',          // Slate 800
        },
        
        // Input colors
        input: {
          bg: '#1E293B',
          border: '#475569',
          focus: '#20B2AA',
          placeholder: '#64748B',
        },
      },
      
      fontFamily: {
        sans: [
          'Inter',
          '-apple-system',
          'BlinkMacSystemFont',
          'Segoe UI',
          'Roboto',
          'Oxygen',
          'Ubuntu',
          'Cantarell',
          'Fira Sans',
          'Droid Sans',
          'Helvetica Neue',
          'sans-serif',
        ],
        mono: [
          'Fira Code',
          'ui-monospace',
          'SFMono-Regular',
          'Menlo',
          'Monaco',
          'Consolas',
          'Liberation Mono',
          'Courier New',
          'monospace',
        ],
      },
      
      fontSize: {
        xs: ['0.75rem', { lineHeight: '1rem' }],      // 12px
        sm: ['0.875rem', { lineHeight: '1.25rem' }],  // 14px
        base: ['1rem', { lineHeight: '1.5rem' }],     // 16px
        lg: ['1.125rem', { lineHeight: '1.75rem' }],  // 18px
        xl: ['1.25rem', { lineHeight: '1.75rem' }],   // 20px
        '2xl': ['1.5rem', { lineHeight: '2rem' }],    // 24px
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }], // 30px
        '4xl': ['2.25rem', { lineHeight: '2.5rem' }], // 36px
        '5xl': ['3rem', { lineHeight: '1' }],         // 48px
        '6xl': ['3.75rem', { lineHeight: '1' }],      // 60px
      },
      
      spacing: {
        '18': '4.5rem',   // 72px
        '88': '22rem',    // 352px
        '100': '25rem',   // 400px
        '120': '30rem',   // 480px
      },
      
      borderRadius: {
        'sm': '0.25rem',  // 4px
        DEFAULT: '0.5rem', // 8px
        'md': '0.625rem', // 10px
        'lg': '0.75rem',  // 12px
        'xl': '1rem',     // 16px
        '2xl': '1.5rem',  // 24px
        '3xl': '2rem',    // 32px
      },
      
      boxShadow: {
        sm: '0 1px 2px 0 rgba(0, 0, 0, 0.25)',
        DEFAULT: '0 1px 3px 0 rgba(0, 0, 0, 0.3), 0 1px 2px -1px rgba(0, 0, 0, 0.3)',
        md: '0 4px 6px -1px rgba(0, 0, 0, 0.3), 0 2px 4px -2px rgba(0, 0, 0, 0.3)',
        lg: '0 10px 15px -3px rgba(0, 0, 0, 0.3), 0 4px 6px -4px rgba(0, 0, 0, 0.3)',
        xl: '0 20px 25px -5px rgba(0, 0, 0, 0.3), 0 8px 10px -6px rgba(0, 0, 0, 0.3)',
        '2xl': '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
        inner: 'inset 0 2px 4px 0 rgba(0, 0, 0, 0.25)',
        glow: '0 0 20px rgba(32, 178, 170, 0.3)',
      },
      
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'slide-down': 'slideDown 0.3s ease-out',
        'spin-slow': 'spin 3s linear infinite',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          '0%': { transform: 'translateY(-10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
      
      transitionDuration: {
        '0': '0ms',
        '200': '200ms',
        '300': '300ms',
        '400': '400ms',
        '500': '500ms',
      },
      
      screens: {
        'xs': '475px',
        'sm': '640px',
        'md': '768px',
        'lg': '1024px',
        'xl': '1280px',
        '2xl': '1536px',
        '3xl': '1920px',
      },
      
      zIndex: {
        '0': '0',
        '10': '10',
        '20': '20',
        '30': '30',
        '40': '40',
        '50': '50',
        '60': '60',
        '70': '70',
        '80': '80',
        '90': '90',
        '100': '100',
        'auto': 'auto',
      },
    },
  },
  plugins: [],
};

export default config;

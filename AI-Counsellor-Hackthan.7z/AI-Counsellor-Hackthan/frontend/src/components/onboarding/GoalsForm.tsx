'use client';

import React, { useState } from 'react';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

interface GoalsFormProps {
  onNext: (data: any) => void;
  initialData: any;
}

export const GoalsForm: React.FC<GoalsFormProps> = ({ onNext, initialData }) => {
  const [formData, setFormData] = useState({
    intended_degree: initialData.intended_degree || '',
    field_of_study: initialData.field_of_study || '',
    target_intake: initialData.target_intake || '',
    preferred_countries: initialData.preferred_countries || [],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext(formData);
  };

  const toggleCountry = (country: string) => {
    if (formData.preferred_countries.includes(country)) {
      setFormData({
        ...formData,
        preferred_countries: formData.preferred_countries.filter((c: string) => c !== country),
      });
    } else {
      setFormData({
        ...formData,
        preferred_countries: [...formData.preferred_countries, country],
      });
    }
  };

  return (
    <Card>
      <form onSubmit={handleSubmit} className="space-y-4">
        <h2 className="text-xl font-semibold text-white mb-4">Study Goals</h2>
        
        <Select
          label="Intended Degree"
          options={[
            { value: '', label: 'Select...' },
            { value: 'bachelors', label: "Bachelor's" },
            { value: 'masters', label: "Master's" },
            { value: 'mba', label: 'MBA' },
            { value: 'phd', label: 'PhD' },
          ]}
          value={formData.intended_degree}
          onChange={(e) => setFormData({ ...formData, intended_degree: e.target.value })}
          required
        />
        
        <Input
          label="Field of Study"
          placeholder="e.g., Computer Science, Business, Medicine"
          value={formData.field_of_study}
          onChange={(e) => setFormData({ ...formData, field_of_study: e.target.value })}
          required
        />
        
        <Input
          label="Target Intake"
          placeholder="e.g., Fall 2026, Spring 2027"
          value={formData.target_intake}
          onChange={(e) => setFormData({ ...formData, target_intake: e.target.value })}
          required
        />
        
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Preferred Countries (Select at least one)
          </label>
          <div className="grid grid-cols-2 gap-2">
            {['USA', 'UK', 'Canada', 'Australia', 'Germany', 'Ireland'].map((country) => (
              <label key={country} className="flex items-center space-x-2 text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.preferred_countries.includes(country)}
                  onChange={() => toggleCountry(country)}
                  className="rounded border-border text-primary focus:ring-primary"
                />
                <span>{country}</span>
              </label>
            ))}
          </div>
        </div>

        <Button type="submit" className="w-full" disabled={formData.preferred_countries.length === 0}>
          Next
        </Button>
      </form>
    </Card>
  );
};

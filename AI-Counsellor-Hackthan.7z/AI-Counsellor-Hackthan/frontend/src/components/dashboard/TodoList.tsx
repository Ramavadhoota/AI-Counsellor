'use client';

import React, { useState } from 'react';
import { Check, Circle, Plus, Trash2 } from 'lucide-react';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';

interface Todo {
  id: number;
  title: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  due_date?: string;
}

interface TodoListProps {
  todos: Todo[];
  onToggle: (id: number) => void;
  onDelete: (id: number) => void;
  onAdd: () => void;
}

export const TodoList: React.FC<TodoListProps> = ({
  todos,
  onToggle,
  onDelete,
  onAdd,
}) => {
  const priorityColors = {
    low: 'default' as const,
    medium: 'warning' as const,
    high: 'danger' as const,
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Tasks</h3>
        <Button size="sm" onClick={onAdd}>
          <Plus className="w-4 h-4 mr-1" />
          Add Task
        </Button>
      </div>

      <div className="space-y-3">
        {todos.length === 0 ? (
          <p className="text-center text-gray-500 py-8">No tasks yet</p>
        ) : (
          todos.map((todo) => (
            <div
              key={todo.id}
              className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition"
            >
              <button
                onClick={() => onToggle(todo.id)}
                className="flex-shrink-0"
              >
                {todo.completed ? (
                  <Check className="w-5 h-5 text-green-600" />
                ) : (
                  <Circle className="w-5 h-5 text-gray-400" />
                )}
              </button>

              <div className="flex-1 min-w-0">
                <p
                  className={`text-sm font-medium ${
                    todo.completed ? 'line-through text-gray-400' : 'text-gray-900'
                  }`}
                >
                  {todo.title}
                </p>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant={priorityColors[todo.priority]} size="sm">
                    {todo.priority}
                  </Badge>
                  {todo.due_date && (
                    <span className="text-xs text-gray-500">
                      Due: {new Date(todo.due_date).toLocaleDateString()}
                    </span>
                  )}
                </div>
              </div>

              <button
                onClick={() => onDelete(todo.id)}
                className="flex-shrink-0 text-gray-400 hover:text-red-600 transition"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

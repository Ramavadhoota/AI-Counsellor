export interface User {
  id: string;
  email: string;
  full_name: string;
  onboarding_completed: boolean;
  created_at: string;
}

export interface OnboardingData {
  education_level: string;
  degree: string;
  major: string;
  graduation_year: number;
  gpa?: number;
  intended_degree: string;
  field_of_study: string;
  target_intake: string;
  preferred_countries: string[];
  budget_min: number;
  budget_max: number;
  funding_plan: string;
  ielts_status: string;
  gre_status: string;
  sop_status: string;
}

export interface ProfileStrength {
  academics: 'strong' | 'average' | 'weak';
  exams: 'not_started' | 'in_progress' | 'completed';
  sop: 'not_started' | 'draft' | 'ready';
  overall_score: number;
}

export interface University {
  id: string;
  name: string;
  country: string;
  city: string;
  category: 'dream' | 'target' | 'safe';
  tuition_min: number;
  tuition_max: number;
  acceptance_rate: number;
  fit_score: number;
  risk_level: 'low' | 'medium' | 'high';
  why_fits: string[];
  risks: string[];
  shortlisted?: boolean;
  locked?: boolean;
}

export interface TodoItem {
  id: string;
  title: string;
  description: string;
  category: string;
  deadline?: string;
  completed: boolean;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  actions?: ActionTaken[];
  timestamp: string;
}

export interface ActionTaken {
  type: 'shortlist' | 'lock' | 'create_todo' | 'update_profile';
  data: any;
  message: string;
}

export type Stage = 'building_profile' | 'discovering_universities' | 'finalizing_universities' | 'preparing_applications';

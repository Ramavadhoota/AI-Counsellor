import type { Metadata } from "next";
import { Toaster } from 'react-hot-toast';
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Counsellor - Study Abroad Guidance",
  description: "Get personalized study abroad counseling with AI",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        {children}
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#1e1e1e',
              color: '#e5e7eb',
              border: '1px solid #2a2a2a',
            },
            success: {
              iconTheme: {
                primary: '#10b981',
                secondary: '#1e1e1e',
              },
            },
            error: {
              iconTheme: {
                primary: '#ef4444',
                secondary: '#1e1e1e',
              },
            },
          }}
        />
      </body>
    </html>
  );
}

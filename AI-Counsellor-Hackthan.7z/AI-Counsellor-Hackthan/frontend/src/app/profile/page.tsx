'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Save } from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { profileAPI } from '@/lib/api';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState<any>({});

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const response = await profileAPI.getMe();
      setFormData(response.data);
    } catch (error) {
      toast.error('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await profileAPI.updateMe(formData);
      toast.success('Profile updated successfully!');
    } catch (error) {
      toast.error('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: string, value: any) => {
    setFormData({ ...formData, [field]: value });
  };

  if (loading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-white">Loading...</div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Link href="/dashboard">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-white">Edit Profile</h1>
                <p className="text-gray-400">Update your information</p>
              </div>
            </div>
            <Button onClick={handleSave} disabled={saving}>
              <Save className="w-4 h-4 mr-2" />
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card className="mb-6">
          <h2 className="text-xl font-semibold text-white mb-4">Academic Background</h2>
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Education Level"
              options={[
                { value: 'high_school', label: 'High School' },
                { value: 'bachelors', label: "Bachelor's" },
                { value: 'masters', label: "Master's" },
              ]}
              value={formData.education_level}
              onChange={(e) => updateField('education_level', e.target.value)}
            />
            
            <Input
              label="Degree"
              value={formData.degree}
              onChange={(e) => updateField('degree', e.target.value)}
            />
            
            <Input
              label="Major"
              value={formData.major}
              onChange={(e) => updateField('major', e.target.value)}
            />
            
            <Input
              type="number"
              label="Graduation Year"
              value={formData.graduation_year}
              onChange={(e) => updateField('graduation_year', parseInt(e.target.value))}
            />
          </div>
        </Card>

        <Card className="mb-6">
          <h2 className="text-xl font-semibold text-white mb-4">Study Goals</h2>
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Intended Degree"
              options={[
                { value: 'bachelors', label: "Bachelor's" },
                { value: 'masters', label: "Master's" },
                { value: 'mba', label: 'MBA' },
                { value: 'phd', label: 'PhD' },
              ]}
              value={formData.intended_degree}
              onChange={(e) => updateField('intended_degree', e.target.value)}
            />
            
            <Input
              label="Field of Study"
              value={formData.field_of_study}
              onChange={(e) => updateField('field_of_study', e.target.value)}
            />
            
            <Input
              label="Target Intake"
              value={formData.target_intake}
              onChange={(e) => updateField('target_intake', e.target.value)}
            />
          </div>
        </Card>

        <Card className="mb-6">
          <h2 className="text-xl font-semibold text-white mb-4">Budget</h2>
          <div className="grid grid-cols-2 gap-4">
            <Input
              type="number"
              label="Min Budget (USD/year)"
              value={formData.budget_min}
              onChange={(e) => updateField('budget_min', parseInt(e.target.value))}
            />
            
            <Input
              type="number"
              label="Max Budget (USD/year)"
              value={formData.budget_max}
              onChange={(e) => updateField('budget_max', parseInt(e.target.value))}
            />
          </div>
        </Card>

        <Card>
          <h2 className="text-xl font-semibold text-white mb-4">Exam Status</h2>
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="IELTS/TOEFL"
              options={[
                { value: 'not_started', label: 'Not Started' },
                { value: 'preparing', label: 'Preparing' },
                { value: 'completed', label: 'Completed' },
              ]}
              value={formData.ielts_status}
              onChange={(e) => updateField('ielts_status', e.target.value)}
            />
            
            <Select
              label="GRE/GMAT"
              options={[
                { value: 'not_started', label: 'Not Started' },
                { value: 'preparing', label: 'Preparing' },
                { value: 'completed', label: 'Completed' },
                { value: 'not_required', label: 'Not Required' },
              ]}
              value={formData.gre_status}
              onChange={(e) => updateField('gre_status', e.target.value)}
            />
            
            <Select
              label="SOP Status"
              options={[
                { value: 'not_started', label: 'Not Started' },
                { value: 'draft', label: 'Draft' },
                { value: 'ready', label: 'Ready' },
              ]}
              value={formData.sop_status}
              onChange={(e) => updateField('sop_status', e.target.value)}
            />
          </div>
        </Card>
      </div>
    </div>
  );
}

'use client';

import React, { useState } from 'react';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';

interface BudgetFormProps {
  onNext: (data: any) => void;
  initialData: any;
}

export const BudgetForm: React.FC<BudgetFormProps> = ({ onNext, initialData }) => {
  const [formData, setFormData] = useState({
    budget_min: initialData.budget_min || '',
    budget_max: initialData.budget_max || '',
    funding_plan: initialData.funding_plan || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext(formData);
  };

  return (
    <Card>
      <form onSubmit={handleSubmit} className="space-y-4">
        <h2 className="text-xl font-semibold text-white mb-4">Budget & Funding</h2>
        
        <div className="grid grid-cols-2 gap-4">
          <Input
            type="number"
            label="Minimum Budget (USD/year)"
            placeholder="15000"
            value={formData.budget_min}
            onChange={(e) => setFormData({ ...formData, budget_min: e.target.value })}
            required
          />
          
          <Input
            type="number"
            label="Maximum Budget (USD/year)"
            placeholder="30000"
            value={formData.budget_max}
            onChange={(e) => setFormData({ ...formData, budget_max: e.target.value })}
            required
          />
        </div>
        
        <Select
          label="Funding Plan"
          options={[
            { value: '', label: 'Select...' },
            { value: 'self_funded', label: 'Self-Funded' },
            { value: 'scholarship', label: 'Scholarship-Dependent' },
            { value: 'loan', label: 'Education Loan' },
            { value: 'mixed', label: 'Mixed (Self + Loan/Scholarship)' },
          ]}
          value={formData.funding_plan}
          onChange={(e) => setFormData({ ...formData, funding_plan: e.target.value })}
          required
        />

        <div className="bg-primary/10 border border-primary/30 rounded-lg p-4 mt-4">
          <p className="text-sm text-gray-300">
            💡 <strong>Tip:</strong> Be realistic with your budget. This will help us recommend 
            universities that match your financial capacity.
          </p>
        </div>

        <Button type="submit" className="w-full">Next</Button>
      </form>
    </Card>
  );
};

export interface University {
  id: string;
  name: string;
  country: string;
  city: string;
  category: 'dream' | 'target' | 'safe';
  tuition_min: number;
  tuition_max: number;
  acceptance_rate: number;
  fit_score: number;
  risk_level: 'low' | 'medium' | 'high';
  why_fits: string[];
  risks: string[];
  shortlisted?: boolean;
  locked?: boolean;
}

export interface UniversityFilters {
  country?: string;
  category?: string;
  budgetMax?: number;
  searchTerm?: string;
}

'use client';

import React, { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  ArrowLeft,
  MapPin,
  DollarSign,
  TrendingUp,
  Star,
  Lock,
  Unlock,
  ExternalLink,
  Calendar,
  Users,
  Award,
  BookOpen,
  Globe,
} from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Progress } from '@/components/ui/Progress';
import { Modal } from '@/components/ui/Modal';
import { api } from '@/lib/api';
import type { University } from '@/types';

export default function UniversityDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const universityId = params.id as string;

  const [university, setUniversity] = useState<University | null>(null);
  const [loading, setLoading] = useState(true);
  const [showLockModal, setShowLockModal] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    fetchUniversityDetails();
  }, [universityId]);

  const fetchUniversityDetails = async () => {
    try {
      const response = await api.get(`/api/universities/${universityId}`);
      setUniversity(response.data);
    } catch (error) {
      console.error('Failed to fetch university details:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleShortlist = async () => {
    if (!university) return;
    setActionLoading(true);

    try {
      await api.post(`/api/universities/${universityId}/shortlist`);
      setUniversity({ ...university, shortlisted: true });
    } catch (error) {
      console.error('Failed to shortlist university:', error);
      alert('Failed to shortlist university. Please try again.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleLock = async () => {
    if (!university) return;
    setActionLoading(true);

    try {
      await api.post(`/api/universities/${universityId}/lock`);
      setUniversity({ ...university, locked: true, shortlisted: true });
      setShowLockModal(false);
      alert('University locked successfully! Check your dashboard for updated tasks.');
    } catch (error) {
      console.error('Failed to lock university:', error);
      alert('Failed to lock university. Please try again.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleUnlock = async () => {
    if (!university) return;
    if (!confirm('Are you sure you want to unlock this university?')) return;

    setActionLoading(true);

    try {
      await api.post(`/api/universities/${universityId}/unlock`);
      setUniversity({ ...university, locked: false });
    } catch (error) {
      console.error('Failed to unlock university:', error);
      alert('Failed to unlock university. Please try again.');
    } finally {
      setActionLoading(false);
    }
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      dream: 'bg-warning/20 text-warning border-warning/30',
      target: 'bg-primary/20 text-primary border-primary/30',
      safe: 'bg-success/20 text-success border-success/30',
    };
    return colors[category as keyof typeof colors] || '';
  };

  const getRiskColor = (risk: string) => {
    const colors = {
      low: 'text-success',
      medium: 'text-warning',
      high: 'text-error',
    };
    return colors[risk as keyof typeof colors] || '';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-400">Loading university details...</p>
        </div>
      </div>
    );
  }

  if (!university) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-gray-400 mb-4">University not found</p>
          <Button onClick={() => router.push('/universities')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Universities
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="secondary"
            onClick={() => router.push('/universities')}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Universities
          </Button>

          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl font-bold text-white">{university.name}</h1>
                <Badge className={getCategoryColor(university.category)}>
                  {university.category}
                </Badge>
              </div>
              <div className="flex items-center text-gray-400 mb-2">
                <MapPin className="w-4 h-4 mr-2" />
                {university.city}, {university.country}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              {university.locked ? (
                <Button
                  variant="outline"
                  onClick={handleUnlock}
                  disabled={actionLoading}
                >
                  <Unlock className="w-4 h-4 mr-2" />
                  Unlock
                </Button>
              ) : university.shortlisted ? (
                <>
                  <Badge variant="info" className="px-4 py-2">
                    <Star className="w-4 h-4 mr-1" />
                    Shortlisted
                  </Badge>
                  <Button onClick={() => setShowLockModal(true)} disabled={actionLoading}>
                    <Lock className="w-4 h-4 mr-2" />
                    Lock University
                  </Button>
                </>
              ) : (
                <Button onClick={handleShortlist} disabled={actionLoading}>
                  <Star className="w-4 h-4 mr-2" />
                  Add to Shortlist
                </Button>
              )}
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content - Left Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Profile Fit Score */}
            <Card>
              <h2 className="text-xl font-semibold text-white mb-4">Profile Fit Analysis</h2>
              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-400">Overall Fit Score</span>
                  <span className="text-2xl font-bold text-primary">{university.fit_score}%</span>
                </div>
                <Progress value={university.fit_score} />
              </div>
              <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                <span className="text-gray-400">Risk Level</span>
                <span className={`font-semibold capitalize ${getRiskColor(university.risk_level)}`}>
                  {university.risk_level}
                </span>
              </div>
            </Card>

            {/* Why This University Fits */}
            {university.why_fits && university.why_fits.length > 0 && (
              <Card>
                <h2 className="text-xl font-semibold text-white mb-4">Why This University Fits You</h2>
                <ul className="space-y-3">
                  {university.why_fits.map((reason, idx) => (
                    <li key={idx} className="flex items-start">
                      <span className="text-success text-xl mr-3">✓</span>
                      <span className="text-gray-300">{reason}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            {/* Potential Risks */}
            {university.risks && university.risks.length > 0 && (
              <Card>
                <h2 className="text-xl font-semibold text-white mb-4">Things to Consider</h2>
                <ul className="space-y-3">
                  {university.risks.map((risk, idx) => (
                    <li key={idx} className="flex items-start">
                      <span className="text-warning text-xl mr-3">⚠</span>
                      <span className="text-gray-300">{risk}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            {/* Program Details (Mock Data - Replace with actual API data) */}
            <Card>
              <h2 className="text-xl font-semibold text-white mb-4">Program Information</h2>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <BookOpen className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-sm text-gray-400">Degree Type</p>
                    <p className="text-white font-medium">Master's</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-sm text-gray-400">Duration</p>
                    <p className="text-white font-medium">2 Years</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Users className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-sm text-gray-400">Class Size</p>
                    <p className="text-white font-medium">30-50 students</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Globe className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-sm text-gray-400">Language</p>
                    <p className="text-white font-medium">English</p>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar - Right Column */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card>
              <h3 className="text-lg font-semibold text-white mb-4">Quick Stats</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center text-gray-400 text-sm mb-1">
                    <DollarSign className="w-4 h-4 mr-2" />
                    Tuition Range
                  </div>
                  <p className="text-white font-semibold">
                    ${university.tuition_min.toLocaleString()} - ${university.tuition_max.toLocaleString()}/year
                  </p>
                </div>

                <div>
                  <div className="flex items-center text-gray-400 text-sm mb-1">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Acceptance Rate
                  </div>
                  <p className="text-white font-semibold">
                    {(university.acceptance_rate * 100).toFixed(1)}%
                  </p>
                </div>

                <div>
                  <div className="flex items-center text-gray-400 text-sm mb-1">
                    <Award className="w-4 h-4 mr-2" />
                    World Ranking
                  </div>
                  <p className="text-white font-semibold">#150 (QS 2024)</p>
                </div>
              </div>
            </Card>

            {/* Application Deadlines (Mock Data) */}
            <Card>
              <h3 className="text-lg font-semibold text-white mb-4">Application Deadlines</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-400">Fall 2025</span>
                  <span className="text-white font-medium">Dec 15, 2024</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Spring 2026</span>
                  <span className="text-white font-medium">Aug 1, 2025</span>
                </div>
              </div>
            </Card>

            {/* Requirements (Mock Data) */}
            <Card>
              <h3 className="text-lg font-semibold text-white mb-4">Requirements</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">IELTS</span>
                  <span className="text-white font-medium">6.5+</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">GRE</span>
                  <span className="text-white font-medium">320+</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Min GPA</span>
                  <span className="text-white font-medium">3.0</span>
                </div>
              </div>
            </Card>

            {/* External Links */}
            <Card>
              <h3 className="text-lg font-semibold text-white mb-4">Resources</h3>
              <div className="space-y-2">
                <a
                  href="#"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-primary hover:text-primary-dark transition-colors"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Official Website
                </a>
                <a
                  href="#"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-primary hover:text-primary-dark transition-colors"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Program Details
                </a>
                <a
                  href="#"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-primary hover:text-primary-dark transition-colors"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Application Portal
                </a>
              </div>
            </Card>
          </div>
        </div>
      </div>

      {/* Lock Confirmation Modal */}
      <Modal
        isOpen={showLockModal}
        onClose={() => setShowLockModal(false)}
        title="Lock University"
        size="md"
      >
        <div className="space-y-4">
          <p className="text-gray-300">
            Locking <strong className="text-white">{university.name}</strong> will:
          </p>
          <ul className="list-disc list-inside text-gray-400 space-y-2">
            <li>Focus your application strategy on this university</li>
            <li>Unlock application guidance and personalized tasks</li>
            <li>Generate a detailed to-do list for this application</li>
            <li>Update your dashboard with university-specific milestones</li>
          </ul>
          <div className="bg-warning/10 border border-warning/30 rounded-lg p-3">
            <p className="text-sm text-gray-300">
              ⚠️ You can unlock later if needed, but it's recommended to commit once you're ready.
            </p>
          </div>
          <div className="flex gap-3 mt-6">
            <Button
              variant="secondary"
              onClick={() => setShowLockModal(false)}
              className="flex-1"
              disabled={actionLoading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleLock}
              className="flex-1"
              disabled={actionLoading}
            >
              {actionLoading ? 'Locking...' : 'Confirm Lock'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

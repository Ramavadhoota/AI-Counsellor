'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
  User, GraduationCap, Target, CheckCircle, 
  MessageSquare, Calendar, LogOut 
} from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { Progress } from '@/components/ui/Progress';
import { profileAPI, todosAPI } from '@/lib/api';
import { useAppStore } from '@/lib/store';
import toast from 'react-hot-toast';

export default function DashboardPage() {
  const router = useRouter();
  const { user, todos, setTodos, currentStage } = useAppStore();
  const [profile, setProfile] = useState<any>(null);
  const [strength, setStrength] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [profileRes, strengthRes, todosRes] = await Promise.all([
        profileAPI.getMe(),
        profileAPI.getStrength(),
        todosAPI.getAll(),
      ]);
      
      setProfile(profileRes.data);
      setStrength(strengthRes.data);
      setTodos(todosRes.data);
    } catch (error: any) {
      toast.error('Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    router.push('/');
  };

  const getStageProgress = () => {
    const stages = ['building_profile', 'discovering_universities', 'finalizing_universities', 'preparing_applications'];
    const currentIndex = stages.indexOf(currentStage);
    return ((currentIndex + 1) / stages.length) * 100;
  };

  if (loading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-white text-xl">Loading...</div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <nav className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-primary-dark rounded-lg" />
              <span className="text-xl font-bold text-white">AI Counsellor</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-400">{user?.full_name}</span>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            Welcome back, {user?.full_name?.split(' ')}!
          </h1>
          <p className="text-gray-400">Here's your study abroad journey overview</p>
        </div>

        {/* Stage Progress */}
        <Card className="mb-8">
          <h2 className="text-xl font-semibold text-white mb-4">Current Stage</h2>
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-300 capitalize">
                {currentStage.replace(/_/g, ' ')}
              </span>
              <span className="text-sm text-gray-400">
                {Math.round(getStageProgress())}% Complete
              </span>
            </div>
            <Progress value={getStageProgress()} />
          </div>
          
          <div className="grid grid-cols-4 gap-4 mt-6">
            {[
              { stage: 'building_profile', label: 'Building Profile', icon: User },
              { stage: 'discovering_universities', label: 'Discovering', icon: GraduationCap },
              { stage: 'finalizing_universities', label: 'Finalizing', icon: Target },
              { stage: 'preparing_applications', label: 'Preparing', icon: CheckCircle },
            ].map((item, index) => {
              const Icon = item.icon;
              const isActive = currentStage === item.stage;
              const isPast = ['building_profile', 'discovering_universities', 'finalizing_universities', 'preparing_applications'].indexOf(currentStage) > index;
              
              return (
                <div
                  key={item.stage}
                  className={`p-4 rounded-lg border ${
                    isActive
                      ? 'bg-primary/10 border-primary'
                      : isPast
                      ? 'bg-success/10 border-success/30'
                      : 'bg-elevated border-border'
                  }`}
                >
                  <Icon className={`w-6 h-6 mb-2 ${isActive ? 'text-primary' : isPast ? 'text-success' : 'text-gray-500'}`} />
                  <p className={`text-sm ${isActive ? 'text-white' : 'text-gray-400'}`}>
                    {item.label}
                  </p>
                </div>
              );
            })}
          </div>
        </Card>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Profile Summary */}
          <Card>
            <h3 className="text-lg font-semibold text-white mb-4">Profile Summary</h3>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-400">Target Degree</p>
                <p className="text-white capitalize">{profile?.intended_degree}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Field of Study</p>
                <p className="text-white">{profile?.field_of_study}</p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Countries</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  {profile?.preferred_countries?.map((country: string) => (
                    <Badge key={country} variant="info">{country}</Badge>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-400">Budget Range</p>
                <p className="text-white">
                  ${profile?.budget_min?.toLocaleString()} - ${profile?.budget_max?.toLocaleString()}
                </p>
              </div>
            </div>
            <Link href="/profile">
              <Button variant="outline" size="sm" className="w-full mt-4">
                Edit Profile
              </Button>
            </Link>
          </Card>

          {/* Profile Strength */}
          <Card>
            <h3 className="text-lg font-semibold text-white mb-4">Profile Strength</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm text-gray-400">Academics</span>
                  <Badge variant={strength?.academics === 'strong' ? 'success' : strength?.academics === 'average' ? 'warning' : 'danger'}>
                    {strength?.academics}
                  </Badge>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm text-gray-400">Exams</span>
                  <Badge variant={strength?.exams === 'completed' ? 'success' : strength?.exams === 'in_progress' ? 'warning' : 'default'}>
                    {strength?.exams?.replace(/_/g, ' ')}
                  </Badge>
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-sm text-gray-400">SOP</span>
                  <Badge variant={strength?.sop === 'ready' ? 'success' : strength?.sop === 'draft' ? 'warning' : 'default'}>
                    {strength?.sop?.replace(/_/g, ' ')}
                  </Badge>
                </div>
              </div>
              <div className="pt-4 border-t border-border">
                <p className="text-sm text-gray-400 mb-2">Overall Score</p>
                <Progress value={strength?.overall_score || 0} showLabel />
              </div>
            </div>
          </Card>

          {/* Quick Actions */}
          <Card>
            <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <Link href="/counsellor">
                <Button variant="primary" className="w-full justify-start">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Talk to AI Counsellor
                </Button>
              </Link>
              <Link href="/universities">
                <Button variant="secondary" className="w-full justify-start">
                  <GraduationCap className="w-4 h-4 mr-2" />
                  Explore Universities
                </Button>
              </Link>
              <Link href="/profile">
                <Button variant="secondary" className="w-full justify-start">
                  <User className="w-4 h-4 mr-2" />
                  Update Profile
                </Button>
              </Link>
            </div>
          </Card>
        </div>

        {/* To-Do List */}
        <Card>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-white">Your To-Do List</h3>
            <Badge variant="info">{todos.filter(t => !t.completed).length} pending</Badge>
          </div>
          
          {todos.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 text-gray-600 mx-auto mb-3" />
              <p className="text-gray-400">No tasks yet. Talk to AI Counsellor to get started!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {todos.slice(0, 5).map((todo) => (
                <div
                  key={todo.id}
                  className={`flex items-start space-x-3 p-3 rounded-lg ${
                    todo.completed ? 'bg-success/10' : 'bg-elevated'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={todo.completed}
                    onChange={() => todosAPI.toggleComplete(todo.id)}
                    className="mt-1 rounded border-border text-primary focus:ring-primary"
                  />
                  <div className="flex-1">
                    <p className={`font-medium ${todo.completed ? 'line-through text-gray-500' : 'text-white'}`}>
                      {todo.title}
                    </p>
                    {todo.description && (
                      <p className="text-sm text-gray-400 mt-1">{todo.description}</p>
                    )}
                    {todo.deadline && (
                      <p className="text-xs text-gray-500 mt-1">
                        Due: {new Date(todo.deadline).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                  <Badge variant="default">{todo.category}</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
